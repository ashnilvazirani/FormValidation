<div>
<?php $__env->startSection('navigation'); ?>
<!-- <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="navbar">Login</a></li>
      <li><a href="list">User List</a></li>
      <li><a href="general">General Validation</a></li>
    </ul>
  </div>
</nav> -->
<?php echo $__env->yieldSection(); ?>
</div><?php /**PATH C:\xampp\htdocs\FormValidation\resources\views/navigation.blade.php ENDPATH**/ ?>