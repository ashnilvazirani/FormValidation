<div class="container">
<?php $__env->startSection('login'); ?>
      <h2>Form Validation using jQuery</h2><br/>
      <form method="POST" action="./loginsubmit" id="form">
        <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <label for="Name">Name:</label>
            <input type="text" class="form-control" name="name">
          </div>
        </div>
        <div class="row" id="email">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Email">Email:</label>
              <input type="text" class="form-control" name="email">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <label for="Number">Phone Number:</label>
              <input type="text" class="form-control" name="number">
            </div>
          </div>
          <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <input type="hidden" class="form-control" id="otp_received" name="otp_received">
            </div>
          </div>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4" style="">
            <button type="submit" id="submit" class="btn btn-success" disabled="disabled">Submit</button>
          </div>
        </div>
      </form>
      <?php echo $__env->yieldSection(); ?>
      <div class="row">
          <div class="col-md-4"></div>
            <div class="form-group col-md-4">
              <button id="btn1" class="btn btn-success">OTP</button>
            </div>
          </div>
    </div>
<!-- <span id="otp_rec">ABCD</span> -->

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
       <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
   <script>
    $(document).ready(function () {
        $("#btn1").click(function(){
        $("#email").append("<div class='row>"+
                        "<div class='col-md-4'></div>"+
                        "<div class='form-group col-md-4'>"+
                        "<label for='OTP'>ENTER THE OTP:</label>"+
                        "<input type='text' class='form-control' name='otp'>"+
                        "</div>"+
                        "</div>");
        $('#btn1').prop('disabled', true);
        $('#submit').prop('disabled', false);
        $.ajax({
            url: './otp',
            type: 'GET',
            success: function(otp){
                console.log(otp);
                $('#otp_received').val(otp);
            }
        });
  });
    $('#form').validate({ // initialize the plugin
        rules: {
            name: {
                required: true
            },
            email: {
                required: true,
                email: true
            },
            number: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 12    
            },
            otp: {
            required: true,
            minlength: 6,
            maxlength: 6
            },
        }
    });
});
</script><?php /**PATH C:\xampp\htdocs\FormValidation\resources\views/login.blade.php ENDPATH**/ ?>