<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NavbarController extends Controller
{
    private $otp;
    public static function getOTP(){
        $otp = mt_rand(100000,999999);
        return $otp;
    }
    function correctOTP($o){
        if($otp==$o){
            return true;
        }
        return false;
    }
}
