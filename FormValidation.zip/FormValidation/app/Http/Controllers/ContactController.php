<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    //
    public function index()
    {
        return view('navbar');
    }       

    public function store(Request $request)
    {  
              
        $data = $request->all();
        $result = Users::insert($data);
        if($result){ 
        	$arr = array('msg' => 'Contact Added Successfully!', 'status' => true);
        }
        return Response()->json($arr);
    }
}
