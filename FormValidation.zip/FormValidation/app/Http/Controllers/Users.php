<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Http\Controllers\NavbarController;
class Users extends Controller
{
    function list(){
        $users = User::all(); 
        return view('userlist',['users'=> $users]);
    }
    function main(){
        return view('navbar');
    }
    function general(){
        return view('general');
    }
    

    function loginsubmit(Request $req){
        // echo "HELLO";
        // print_r($req->input());
        $user = new User();
        $user->name = $req->name;
        $user->email = $req->email;
        $user->number = $req->number;
        if($req->otp == $req->otp_received){
            $user->save();
            return view('navbarsucess');
        }else{
            echo "INVALID OTP";
        }//else closing
        
    }
}
