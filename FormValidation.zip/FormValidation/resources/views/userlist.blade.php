
<!--This is actually a center page-->
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Form Validation using jQuery in Laravel</title>
    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">   -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  </head>
  <body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="navbar">Login</a></li>
      <li><a href="list">User List</a></li>
      <li><a href="general">General Validation</a></li>
    </ul>
  </div>
</nav>

<!-- @extends('navigation') -->
    <!--the above page is Navigation-->
    <h2>User list page</h2>
    <!-- <?php print_r($users);?> -->
    <!DOCTYPE html>

<div class="container">
  <table class="table">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
    @foreach($users as $user)
      <tr>
        <td>{{$user->name}}</td>
        <td>{{$user->email}}</td>
        <td>{{$user->number}}</td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
</body>
  <script src="{{asset('js/app.js')}}"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>     
</html>